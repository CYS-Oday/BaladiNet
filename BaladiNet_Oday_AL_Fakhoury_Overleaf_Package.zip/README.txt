BALADINET - ODAY AL FAKHOURY - LATEX REPORT

FILES
- main.tex: complete editable LaTeX source for the BaladiNet report.
- university_logo.png: the university logo used on the cover page.
- BaladiNet_Report_Oday_AL_Fakhoury.pdf: compiled 34-page A4 report.

OVERLEAF STEPS
1. Open https://www.overleaf.com/ and sign in.
2. Select New Project -> Upload Project.
3. Upload this ZIP archive.
4. Open Menu -> Compiler and select XeLaTeX.
5. Ensure main.tex is selected as the Main document.
6. Click Recompile. If the table of contents is not refreshed, click Recompile once more.
7. Download the PDF from the preview panel.

The report body is the existing BaladiNet / NetBox technical implementation report. The uploaded Linux Command Practice report was used only as a visual reference for the university identity and academic cover arrangement; its command-practice content and steps were not copied into the BaladiNet report.
